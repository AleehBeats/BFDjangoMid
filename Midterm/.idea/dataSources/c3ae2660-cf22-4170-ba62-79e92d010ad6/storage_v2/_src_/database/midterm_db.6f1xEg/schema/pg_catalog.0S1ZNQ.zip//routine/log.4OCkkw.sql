create function log(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.log(10, $1)
$$;

comment on function log(numeric) is 'base 10 logarithm';

alter function log(numeric) owner to postgres;

